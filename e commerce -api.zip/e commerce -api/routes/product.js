const express = require('express');
const router = express.Router();

// In-memory products array (replace with database in production)
let products = [
    { id: 1, name: 'Laptop', price: 999.99, category: 'Electronics' },
    { id: 2, name: 'Smartphone', price: 699.99, category: 'Electronics' },
    { id: 3, name: 'Headphones', price: 149.99, category: 'Electronics' }
];

// GET /products - Get all products
router.get('/', (req, res) => {
    try {
        res.json({
            success: true,
            count: products.length,
            data: products
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error fetching products'
        });
    }
});

// POST /products - Add a new product
router.post('/', (req, res) => {
    try {
        const { name, price, category } = req.body;

        // Basic validation
        if (!name || !price || !category) {
            return res.status(400).json({
                success: false,
                message: 'Name, price, and category are required'
            });
        }

        // Create new product
        const newProduct = {
            id: products.length + 1,
            name,
            price: parseFloat(price),
            category
        };

        products.push(newProduct);

        res.status(201).json({
            success: true,
            message: 'Product added successfully',
            data: newProduct
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Error adding product'
        });
    }
});

module.exports = router;